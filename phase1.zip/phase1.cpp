#include<iostream>
#include<conio.h>
#include<iomanip>
using namespace std;

//For Stoping and Clearing Screen
void hault();

//Menu Functions Declarations
int MainMenu();
int AdminMenu();
int ManagerMenu();
int SalesmanMenu();
int StorekeeperMenu();

int main()
{
    start:
    int x;
    x = MainMenu();
    if(x==1)
    {
        string username,password;
        int admin;
        char a;
        while(username != "admin" || password != "qwerty")
        {
        system("CLS");
        cout << "\t\t\t||***__ENTER YOUR CREDENTIALS__***||\n\n";
        cout << "ENTER USERNAME: ";
        cin >> username;
        cout << "ENTER PASSWORD: ";
        cin >> password;
            if(username != "admin" || password != "qwerty")
            {
                cout << "\t\t\tINVALID DETAILS\n";
                cout << "DO YOU WANT TO GO BACK TO MAIN MENU (Y/N): ";
                cin >> a;
                if(a == 'Y' || a == 'y')
                {
                    goto start;
                }
                hault();
            }
        }
        do
        {
            admin=AdminMenu();
            switch (admin)
            {
            case 1:
                /* code */
                break;
            case 2:
                /* code */
                break;
            case 3:
                /* code */
                break;
            case 4:
                /* code */
                break;
            case 5:
                /* code */
                break;
            case 6:
                /* code */
            break;
            case 7:
                /* code */
                break;
            case 8:
                /* code */
                break;
            case 9:
                goto start;
                break;
            case 10:
                cout << "\t\t\t\tTHANK YOU! FOR USING THE PROGRAM";
                break;
        
            default:
                cout << "INVALID CHOICE\n";
                hault();
                break;
            }
        }while(admin!=10);
    }
    else if(x==2)
    {
        int manager;
        do
        {
            manager=ManagerMenu();
            switch (manager)
            {
            case 1:
                /* code */
                break;
            case 2:
                /* code */
                break;
            case 3:
                /* code */
                break;
            case 4:
                /* code */
                break;
            case 5:
                /* code */
                break;
            case 6:
                /* code */
                break;
            case 7:
                /* code */
                break;
            case 8:
                /* code */
                break;
            case 9:
                /* code */
                break;
            case 10:
                /* code */
                break;
            case 11:
                goto start;
                break;
            case 12:
                cout << "\t\t\t\tTHANK YOU! FOR USING THE PROGRAM";
                break;
            default:
                cout << "INVALID CHOICE\n";
                break;
            }
        } while (manager!=12);
        
    }
    else if(x==3)
    {
        int salesman;
        do
        {
            salesman=SalesmanMenu();
             switch (salesman)
            {
            case 1:
                /* code */
                break;
            case 2:
                /* code */
                break;
            case 3:
                /* code */
                break;
            case 4:
                /* code */
                break;
            case 5:
                /* code */
                break;
            case 6:
                goto start;
            break;
            case 7:
                cout << "\t\t\t\tTHANK YOU! FOR USING THE PROGRAM";
                break;
        
            default:
            cout << "INVALID CHOICE\n";
            hault();
            break;
            }
        } while (salesman!=7);
        
    }
    else if(x==4)
    {
        int stockman;
        do
        {
             stockman=StorekeeperMenu();
            switch (stockman)
            {
            case 1:
                /* code */
                break;
            case 2:
                /* code */
                break;
            case 3:
                /* code */
                break;
            case 4:
                /* code */
                break;
            case 5:
                goto start;
            break;
            case 6:
                cout << "\t\t\t\tTHANK YOU! FOR USING THE PROGRAM";
                break;

            default:
            cout << "INVALID CHOICE\n";
            hault();
            break;
            }
        } while (stockman!=6);
        
    }
    else if(x==0)
    {
        cout << "\t\t\t\tTHANK YOU! FOR USING THE PROGRAM";
    }
    else
    {
        cout << "INVALID CHOICE";
        goto start;
    }
    
  return 0;
}

void hault()
{
    cout << "Press any key to Continue......\n";
    getch();
    system("CLS");
}
int MainMenu()
{
    int a;
    system("CLS");
    cout << "\t\t--------------------------------------------------------------------\n"
            "\t\t\t***** WELCOME TO SUPERMARKET SYSTEM MANAGEMENT *****\n"
            "\t\t--------------------------------------------------------------------\n\n"
            "\t\t\t\t\t||--  MAIN MENU  --||\n\n"
            "\t\t\t\t1. LOGIN AS ADMINISTRATIVE\n"
            "\t\t\t\t2. LOGIN AS MANAGER\n"
            "\t\t\t\t3. LOGIN AS SALESMAN\n"
            "\t\t\t\t4. LOGIN AS STOREKEEPER\n"
            "\t\t\t\t0. TO CLOSE THE PROGRAM\n\n"
            "\t\tENTER YOUR OPTION: ";
    cin >> a;
    return a;
}

int AdminMenu()
{
    int b;
    system("CLS");
    cout << "1. ADD MANAGER\n"
            "2. ADD SALESMAN\n"
            "3. ADD STOREKEEPER\n"
            "4. VIEW SALES OF SALESMAN\n"
            "5. TOTAL SALES\n"
            "6. VIEW ALL SALESMAN WITH SALARY\n"
            "7. VIEW ALL STOCKMAN WITH SALARY\n"
            "8. VIEW ALL PRODUCTS\n"
            "9. GO BACK TO MAIN MENU\n"
            "10. TO EXIT THE PROGRAM\n"
            "ENTER YOUR OPTION: ";
    cin >> b;
    return b;
}

int ManagerMenu()
{
    int b;
    system("CLS");
    cout << "1. ADD SALESMAN BONUS\n"
            "2. ADD STOREKEEPER BONUS\n" 
            "3. GIVE SALESMAN & STOCKMAN SALARY\n"
            "4. VIEW SALES OF SALESMAN\n"
            "5. TOTAL SALES\n"
            "6. VIEW ALL SALESMAN WITH SALARY\n"
            "7. VIEW ALL STOREKEEPER WITH SALARY\n"
            "8. VIEW ALL PRODUCTS\n"
            "9. VIEW SALESMAN WITH GREATEST & SMALLEST SALES\n"
            "10.VIEW PRODUCT WITH MAXIMUM SALE & MINIMUM SALE\n"
            "11. GO BACK TO MAIN MENU\n"
            "12. TO EXIT THE PROGRAM\n\n"
            "ENTER YOUR OPTION: ";
    cin >> b;
    return b;
}

int SalesmanMenu()
{
    int b;
    system("CLS");
    cout << "1. SALE PRODUCT\n"
            "2. RETURN PRODUCT\n"
            "3. VIEW ALL PRODUCTS\n"
            "4. VIEW YOUR SALES\n"
            "5. VIEW YOUR BONUS\n"
            "6. GO BACK TO MAIN MENU\n"
            "7. TO EXIT THE PROGRAM\n\n"
            "ENTER YOUR OPTION: ";
    cin >> b;
    return b;
}

int StorekeeperMenu()
{
    int b;
    system("CLS");
    cout << "1. ADD PRODUCT\n"
            "2. DELETE PRODUCT\n"
            "3. VIEW ALL PRODUCTS\n"
            "4. VIEW YOUR SALARY\n"
            "5. GO BACK TO MAIN MENU\n"
            "6. TO EXIT THE PROGRAM\n\n"
            "ENTER YOUR OPTION: ";
    cin >> b;
    return b;
}